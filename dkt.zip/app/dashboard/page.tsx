'use client';

import { useEffect } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import {
  TrendingUp,
  Wallet,
  ArrowDownLeft,
  ArrowUpRight,
  Clock,
  CreditCard,
  Bitcoin,
  DollarSign,
  BarChart3,
  ChevronRight,
} from 'lucide-react';
import { useStore } from '@/lib/supabase/store-supabase';
import { useUnifiedBalance } from '@/hooks/useUnifiedBalance';

export default function DashboardPage() {
  const { user, refreshUser, trades, loadTrades } = useStore();
  const { balance } = useUnifiedBalance();

  useEffect(() => {
    refreshUser();
    loadTrades();
  }, []);

  const recentTrades = (trades || []).slice(0, 8);
  const totalBalance = balance.total;

  return (
    <div className="p-4 lg:p-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-display font-bold text-cream">
          Welcome back{user?.firstName ? `, ${user.firstName}` : ''}
        </h1>
        <p className="text-slate-400 mt-1">Here&apos;s your account overview</p>
      </div>

      {/* Balance Cards */}
      <div className="grid sm:grid-cols-3 gap-4 mb-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-br from-gold/20 to-gold/5 rounded-2xl border border-gold/20 p-5"
        >
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-gold/20 rounded-xl flex items-center justify-center">
              <Wallet className="w-5 h-5 text-gold" />
            </div>
            <span className="text-sm text-cream/60">Available Balance</span>
          </div>
          <p className="text-3xl font-bold text-cream">
            ${balance.available.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </p>
          {balance.bonus > 0 && (
            <p className="text-xs text-profit mt-1">+${balance.bonus.toLocaleString()} bonus</p>
          )}
          {totalBalance === 0 && (
            <Link
              href="/dashboard/wallet"
              className="inline-flex items-center gap-1.5 mt-3 text-xs text-gold hover:text-gold/80"
            >
              <CreditCard className="w-3.5 h-3.5" />
              Make your first deposit
            </Link>
          )}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white/5 rounded-2xl border border-white/5 p-5"
        >
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-profit/10 rounded-xl flex items-center justify-center">
              <ArrowDownLeft className="w-5 h-5 text-profit" />
            </div>
            <span className="text-sm text-cream/60">Total Deposited</span>
          </div>
          <p className="text-3xl font-bold text-cream">
            ${(user?.totalDeposited || 0).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white/5 rounded-2xl border border-white/5 p-5"
        >
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-electric/10 rounded-xl flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-electric" />
            </div>
            <span className="text-sm text-cream/60">Total Trades</span>
          </div>
          <p className="text-3xl font-bold text-cream">{(trades || []).length}</p>
        </motion.div>
      </div>

      {/* Quick Actions */}
      <div className="grid sm:grid-cols-4 gap-3 mb-8">
        {[
          { label: 'Deposit', href: '/dashboard/wallet', icon: CreditCard, primary: true },
          { label: 'Trade Crypto', href: '/dashboard/trade/crypto', icon: Bitcoin, primary: false },
          { label: 'Trade Forex', href: '/dashboard/trade/fx', icon: DollarSign, primary: false },
          { label: 'Trade Stocks', href: '/dashboard/trade/stocks', icon: BarChart3, primary: false },
        ].map((action) => (
          <Link
            key={action.label}
            href={action.href}
            className={`flex items-center gap-3 px-4 py-3.5 rounded-xl font-medium text-sm transition-all ${
              action.primary
                ? 'bg-gradient-to-r from-gold to-gold/80 text-void hover:shadow-lg hover:shadow-gold/20'
                : 'bg-white/5 text-cream hover:bg-white/10 border border-white/5'
            }`}
          >
            <action.icon className="w-5 h-5" />
            {action.label}
            <ChevronRight className="w-4 h-4 ml-auto opacity-50" />
          </Link>
        ))}
      </div>

      {/* Recent Activity */}
      <div className="bg-white/5 rounded-2xl border border-white/5 p-5">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-cream">Recent Activity</h2>
          {recentTrades.length > 0 && (
            <Link href="/dashboard/history" className="text-sm text-gold hover:text-gold/80">
              View all →
            </Link>
          )}
        </div>

        {recentTrades.length === 0 ? (
          <div className="text-center py-12">
            <Clock className="w-12 h-12 text-cream/20 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-cream mb-2">No Activity Yet</h3>
            <p className="text-cream/60 mb-4 text-sm">
              Start trading or make a deposit to see your activity here.
            </p>
            <Link
              href="/dashboard/wallet"
              className="inline-flex items-center gap-2 px-5 py-2.5 bg-gold text-void font-semibold rounded-xl hover:bg-gold/90 transition-colors text-sm"
            >
              <CreditCard className="w-4 h-4" />
              Get Started
            </Link>
          </div>
        ) : (
          <div className="space-y-2">
            {recentTrades.map((trade) => {
              const isProfit = trade.pnl >= 0;
              return (
                <div
                  key={trade.id}
                  className="flex items-center gap-4 p-3 bg-white/5 rounded-xl"
                >
                  <div
                    className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                      trade.type === 'buy' ? 'bg-profit/10' : 'bg-loss/10'
                    }`}
                  >
                    {trade.type === 'buy' ? (
                      <ArrowDownLeft className="w-5 h-5 text-profit" />
                    ) : (
                      <ArrowUpRight className="w-5 h-5 text-loss" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="font-medium text-cream text-sm">{trade.pair}</p>
                      <span
                        className={`text-xs px-1.5 py-0.5 rounded ${
                          trade.type === 'buy' ? 'bg-profit/10 text-profit' : 'bg-loss/10 text-loss'
                        }`}
                      >
                        {trade.type.toUpperCase()}
                      </span>
                    </div>
                    <p className="text-xs text-cream/50 mt-0.5">
                      {new Date(trade.createdAt).toLocaleDateString()} • ${trade.amount.toLocaleString()}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className={`text-sm font-semibold ${isProfit ? 'text-profit' : 'text-loss'}`}>
                      {isProfit ? '+' : ''}${trade.pnl.toFixed(2)}
                    </p>
                    <span
                      className={`text-xs font-medium px-1.5 py-0.5 rounded-full ${
                        trade.status === 'closed'
                          ? 'bg-profit/10 text-profit'
                          : trade.status === 'open'
                          ? 'bg-yellow-500/10 text-yellow-500'
                          : 'bg-loss/10 text-loss'
                      }`}
                    >
                      {trade.status}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
