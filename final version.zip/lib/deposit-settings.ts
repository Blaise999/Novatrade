import { create } from 'zustand';
import { persist } from 'zustand/middleware';

// Crypto wallet configuration
export interface CryptoWallet {
  id: string;
  symbol: string;
  name: string;
  network: string;
  address: string;
  qrCode?: string; // Base64 or URL
  enabled: boolean;
  minDeposit: number;
  confirmations: number;
  icon: string;
}

// Bank account configuration
export interface BankAccount {
  id: string;
  bankName: string;
  accountName: string;
  accountNumber: string;
  routingNumber?: string;
  swiftCode?: string;
  iban?: string;
  country: string;
  currency: string;
  enabled: boolean;
  minDeposit: number;
  instructions?: string;
}

// Mobile money / Payment processor
export interface PaymentProcessor {
  id: string;
  name: string;
  type: 'mobile_money' | 'card' | 'ewallet' | 'other';
  accountId: string; // Phone number, email, etc.
  accountName: string;
  country?: string;
  enabled: boolean;
  minDeposit: number;
  fee: string;
  instructions?: string;
  icon: string;
}

// Pending deposit from user
export interface PendingDeposit {
  id: string;
  oderId: string;
  amount: number;
  method: 'crypto' | 'bank' | 'processor';
  methodId: string; // Which crypto/bank/processor was used
  methodName: string;
  transactionRef?: string; // User provided reference
  proofImage?: string; // Base64 screenshot
  userId: string;
  userEmail: string;
  status: 'pending' | 'confirmed' | 'rejected';
  createdAt: Date;
  processedAt?: Date;
  processedBy?: string;
  note?: string;
}

// Platform settings
export interface DepositSettings {
  // Crypto wallets (admin controlled)
  cryptoWallets: CryptoWallet[];
  // Bank accounts (admin controlled)
  bankAccounts: BankAccount[];
  // Payment processors (mobile money, etc.)
  paymentProcessors: PaymentProcessor[];
  // Pending deposits awaiting admin confirmation
  pendingDeposits: PendingDeposit[];
  // Confirmed deposits history
  confirmedDeposits: PendingDeposit[];
  // Global settings
  globalMinDeposit: number;
  depositInstructions: string;
  supportEmail: string;
  supportWhatsApp?: string;
  requireProof: boolean;
  autoApproveThreshold: number; // 0 = manual approval for all
}

interface DepositSettingsStore extends DepositSettings {
  // Crypto wallet management
  addCryptoWallet: (wallet: Omit<CryptoWallet, 'id'>) => void;
  updateCryptoWallet: (id: string, updates: Partial<CryptoWallet>) => void;
  removeCryptoWallet: (id: string) => void;
  toggleCryptoWallet: (id: string) => void;
  
  // Bank account management
  addBankAccount: (account: Omit<BankAccount, 'id'>) => void;
  updateBankAccount: (id: string, updates: Partial<BankAccount>) => void;
  removeBankAccount: (id: string) => void;
  toggleBankAccount: (id: string) => void;
  
  // Payment processor management
  addPaymentProcessor: (processor: Omit<PaymentProcessor, 'id'>) => void;
  updatePaymentProcessor: (id: string, updates: Partial<PaymentProcessor>) => void;
  removePaymentProcessor: (id: string) => void;
  togglePaymentProcessor: (id: string) => void;
  
  // Deposit management
  submitDeposit: (deposit: Omit<PendingDeposit, 'id' | 'status' | 'createdAt'>) => string;
  confirmDeposit: (depositId: string, adminId: string, note?: string) => PendingDeposit | null;
  rejectDeposit: (depositId: string, adminId: string, note?: string) => PendingDeposit | null;
  
  // Settings
  updateGlobalSettings: (settings: Partial<Pick<DepositSettings, 'globalMinDeposit' | 'depositInstructions' | 'supportEmail' | 'supportWhatsApp' | 'requireProof' | 'autoApproveThreshold'>>) => void;
  
  // Getters
  getEnabledCryptoWallets: () => CryptoWallet[];
  getEnabledBankAccounts: () => BankAccount[];
  getEnabledPaymentProcessors: () => PaymentProcessor[];
  getPendingDeposits: () => PendingDeposit[];
  getUserDeposits: (userId: string) => PendingDeposit[];
}

// Default crypto wallets (admin should update these)
const defaultCryptoWallets: CryptoWallet[] = [
  {
    id: 'btc-1',
    symbol: 'BTC',
    name: 'Bitcoin',
    network: 'Bitcoin',
    address: 'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh',
    enabled: true,
    minDeposit: 50,
    confirmations: 3,
    icon: '₿'
  },
  {
    id: 'eth-1',
    symbol: 'ETH',
    name: 'Ethereum',
    network: 'ERC-20',
    address: '0x742d35Cc6634C0532925a3b844Bc454e4438f44E',
    enabled: true,
    minDeposit: 50,
    confirmations: 12,
    icon: 'Ξ'
  },
  {
    id: 'usdt-trc20',
    symbol: 'USDT',
    name: 'Tether',
    network: 'TRC-20',
    address: 'TN3W4H6rK2ce4vX9YnFQHwKENnHjoxb3m9',
    enabled: true,
    minDeposit: 20,
    confirmations: 20,
    icon: '₮'
  },
  {
    id: 'usdt-erc20',
    symbol: 'USDT',
    name: 'Tether',
    network: 'ERC-20',
    address: '0x742d35Cc6634C0532925a3b844Bc454e4438f44E',
    enabled: true,
    minDeposit: 50,
    confirmations: 12,
    icon: '₮'
  },
  {
    id: 'sol-1',
    symbol: 'SOL',
    name: 'Solana',
    network: 'Solana',
    address: '5eykt4UsFv8P8NJdTREpY1vzqKqZKvdpKuc147dw2N9d',
    enabled: false,
    minDeposit: 25,
    confirmations: 32,
    icon: '◎'
  },
];

// Default bank accounts (admin should update these)
const defaultBankAccounts: BankAccount[] = [
  {
    id: 'bank-1',
    bankName: 'First National Bank',
    accountName: 'Nova Trade Ltd',
    accountNumber: '1234567890',
    routingNumber: '021000021',
    country: 'United States',
    currency: 'USD',
    enabled: false,
    minDeposit: 100,
    instructions: 'Please use your account email as the payment reference.'
  },
];

// Default payment processors
const defaultPaymentProcessors: PaymentProcessor[] = [
  {
    id: 'paypal-1',
    name: 'PayPal',
    type: 'ewallet',
    accountId: 'payments@novatrade.com',
    accountName: 'Nova Trade Ltd',
    enabled: false,
    minDeposit: 50,
    fee: '3.5%',
    instructions: 'Send as Friends & Family to avoid fees.',
    icon: '💳'
  },
  {
    id: 'cashapp-1',
    name: 'Cash App',
    type: 'ewallet',
    accountId: '$NovaTradeOfficial',
    accountName: 'Nova Trade',
    country: 'United States',
    enabled: false,
    minDeposit: 25,
    fee: '0%',
    instructions: 'Include your registered email in the note.',
    icon: '💵'
  },
];

const generateId = () => `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

export const useDepositSettingsStore = create<DepositSettingsStore>()(
  persist(
    (set, get) => ({
      cryptoWallets: defaultCryptoWallets,
      bankAccounts: defaultBankAccounts,
      paymentProcessors: defaultPaymentProcessors,
      pendingDeposits: [],
      confirmedDeposits: [],
      globalMinDeposit: 20,
      depositInstructions: 'After making your deposit, please submit the transaction details below. Our team will verify and credit your account within 1-24 hours.',
      supportEmail: 'support@novatrade.com',
      supportWhatsApp: '+1234567890',
      requireProof: true,
      autoApproveThreshold: 0,

      // Crypto wallet management
      addCryptoWallet: (wallet) => set((state) => ({
        cryptoWallets: [...state.cryptoWallets, { ...wallet, id: generateId() }]
      })),

      updateCryptoWallet: (id, updates) => set((state) => ({
        cryptoWallets: state.cryptoWallets.map(w => w.id === id ? { ...w, ...updates } : w)
      })),

      removeCryptoWallet: (id) => set((state) => ({
        cryptoWallets: state.cryptoWallets.filter(w => w.id !== id)
      })),

      toggleCryptoWallet: (id) => set((state) => ({
        cryptoWallets: state.cryptoWallets.map(w => 
          w.id === id ? { ...w, enabled: !w.enabled } : w
        )
      })),

      // Bank account management
      addBankAccount: (account) => set((state) => ({
        bankAccounts: [...state.bankAccounts, { ...account, id: generateId() }]
      })),

      updateBankAccount: (id, updates) => set((state) => ({
        bankAccounts: state.bankAccounts.map(a => a.id === id ? { ...a, ...updates } : a)
      })),

      removeBankAccount: (id) => set((state) => ({
        bankAccounts: state.bankAccounts.filter(a => a.id !== id)
      })),

      toggleBankAccount: (id) => set((state) => ({
        bankAccounts: state.bankAccounts.map(a => 
          a.id === id ? { ...a, enabled: !a.enabled } : a
        )
      })),

      // Payment processor management
      addPaymentProcessor: (processor) => set((state) => ({
        paymentProcessors: [...state.paymentProcessors, { ...processor, id: generateId() }]
      })),

      updatePaymentProcessor: (id, updates) => set((state) => ({
        paymentProcessors: state.paymentProcessors.map(p => p.id === id ? { ...p, ...updates } : p)
      })),

      removePaymentProcessor: (id) => set((state) => ({
        paymentProcessors: state.paymentProcessors.filter(p => p.id !== id)
      })),

      togglePaymentProcessor: (id) => set((state) => ({
        paymentProcessors: state.paymentProcessors.map(p => 
          p.id === id ? { ...p, enabled: !p.enabled } : p
        )
      })),

      // Deposit management
      submitDeposit: (deposit) => {
        const id = generateId();
        set((state) => ({
          pendingDeposits: [
            ...state.pendingDeposits,
            {
              ...deposit,
              id,
              status: 'pending',
              createdAt: new Date()
            }
          ]
        }));
        return id;
      },

      confirmDeposit: (depositId, adminId, note) => {
        const state = get();
        const deposit = state.pendingDeposits.find(d => d.id === depositId);
        if (!deposit) return null;

        const confirmedDeposit: PendingDeposit = {
          ...deposit,
          status: 'confirmed',
          processedAt: new Date(),
          processedBy: adminId,
          note
        };

        set((state) => ({
          pendingDeposits: state.pendingDeposits.filter(d => d.id !== depositId),
          confirmedDeposits: [...state.confirmedDeposits, confirmedDeposit]
        }));

        return confirmedDeposit;
      },

      rejectDeposit: (depositId, adminId, note) => {
        const state = get();
        const deposit = state.pendingDeposits.find(d => d.id === depositId);
        if (!deposit) return null;

        const rejectedDeposit: PendingDeposit = {
          ...deposit,
          status: 'rejected',
          processedAt: new Date(),
          processedBy: adminId,
          note
        };

        set((state) => ({
          pendingDeposits: state.pendingDeposits.filter(d => d.id !== depositId),
          confirmedDeposits: [...state.confirmedDeposits, rejectedDeposit]
        }));

        return rejectedDeposit;
      },

      // Settings
      updateGlobalSettings: (settings) => set((state) => ({
        ...state,
        ...settings
      })),

      // Getters
      getEnabledCryptoWallets: () => get().cryptoWallets.filter(w => w.enabled),
      getEnabledBankAccounts: () => get().bankAccounts.filter(a => a.enabled),
      getEnabledPaymentProcessors: () => get().paymentProcessors.filter(p => p.enabled),
      getPendingDeposits: () => get().pendingDeposits.filter(d => d.status === 'pending'),
      getUserDeposits: (userId) => [
        ...get().pendingDeposits.filter(d => d.userId === userId),
        ...get().confirmedDeposits.filter(d => d.userId === userId)
      ].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()),
    }),
    {
      name: 'deposit-settings-storage',
    }
  )
);
