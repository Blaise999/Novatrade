declare module "lightweight-charts" {
  export const CrosshairMode: any;
  export function createChart(container: any, options?: any): any;
}
