import Header from "@/components/landing/Header";
import HeroMorph from "@/components/landing/HeroMorph";
import Ticker from "@/components/landing/Ticker";
import TrustBar from "@/components/landing/TrustBar";
import Markets from "@/components/landing/Markets";
import PlatformShowcase from "@/components/landing/PlatformShowcase";
import Tools from "@/components/landing/Tools";
import Security from "@/components/landing/Security";
import Pricing from "@/components/landing/Pricing";
import Testimonials from "@/components/landing/Testimonials";
import FAQ from "@/components/landing/FAQ";
import CTA from "@/components/landing/CTA";
import Footer from "@/components/landing/Footer";

export default function HomePage() {
  return (
    <main>
      <Header />
      <HeroMorph />
      <Ticker />
      <TrustBar />
      <Markets />
      <PlatformShowcase />
      <Tools />
      <Security />
      <Pricing />
      <Testimonials />
      <FAQ />
      <CTA />
      <Footer />
    </main>
  );
}
