import Section from "@/components/ui/Section";

const rules = [
  {
    title: "Time unlock",
    desc: "Bonus remains locked until a timeline is reached (e.g., 7 days), or vests gradually (10% daily).",
    bullets: ["Simple", "Predictable", "Perfect for weekly training"],
  },
  {
    title: "Closed-trade unlock",
    desc: "Bonus unlocks after N closed trades. Add a minimum hold time to block spam opens/closes.",
    bullets: ["Practice-driven", "Easy to measure", "Works with milestones"],
  },
  {
    title: "Hybrid unlock",
    desc: "Unlock after N trades OR X days (whichever comes first) — fair and reduces frustration.",
    bullets: ["Retention-friendly", "Feels fair", "Best default"],
  },
];

export default function BonusUnlock() {
  return (
    <Section id="bonus">
      <h2 className="text-2xl font-semibold text-white">Bonus unlock rules (promo, not withdrawals)</h2>
      <p className="mt-2 max-w-3xl text-white/65">
        Your earlier request is best implemented as a <span className="text-white">bonus wallet</span>:
        the bonus is locked by policy, while the “main balance” stays separate. This avoids confusion and keeps it honest.
      </p>

      <div className="mt-8 grid gap-4 lg:grid-cols-3">
        {rules.map((r) => (
          <div key={r.title} className="rounded-2xl border border-white/10 bg-white/5 p-5">
            <div className="text-sm font-semibold text-white">{r.title}</div>
            <div className="mt-2 text-sm text-white/65">{r.desc}</div>
            <div className="mt-4 grid gap-2 text-sm text-white/70">
              {r.bullets.map((b) => (
                <div key={b} className="rounded-xl border border-white/10 bg-white/5 px-4 py-2">
                  {b}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 rounded-2xl border border-white/10 bg-white/5 p-5 text-sm text-white/70">
        Recommended defaults: <span className="text-white">closed trades only</span>, minimum hold time{" "}
        <span className="text-white">60s</span>, milestone unlock{" "}
        <span className="text-white">25/50/75/100%</span>.
      </div>
    </Section>
  );
}
