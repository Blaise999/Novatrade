import Section from "@/components/ui/Section";
import { ButtonLink } from "@/components/ui/Button";

export default function CTA() {
  return (
    <Section id="cta" className="py-16 sm:py-24">
      <div className="rounded-3xl border border-white/10 bg-white/5 p-7 sm:p-10">
        <div className="grid gap-8 md:grid-cols-[1.2fr_.8fr] md:items-center">
          <div>
            <div className="text-xs uppercase tracking-wide text-white/55">Start now</div>
            <h3 className="mt-2 text-3xl font-semibold tracking-tight text-white">
              Launch your first classroom session in minutes.
            </h3>
            <p className="mt-3 max-w-2xl text-white/65">
              NovaTrade’s landing is built to sell the full story: controlled outcomes, proof logs,
              and a broker-style trading UI. Next we’ll wire the terminal + admin session generator.
            </p>

            <div className="mt-6 flex flex-wrap gap-3">
              <ButtonLink href="#" variant="primary" size="lg">
                Create demo account
              </ButtonLink>
              <ButtonLink href="#platform" variant="secondary" size="lg">
                Review platform
              </ButtonLink>
            </div>

            <div className="mt-4 text-xs text-white/45">
              Disclaimer: Educational simulator starter. No real funds or brokerage services.
            </div>
          </div>

          <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
            <div className="text-sm font-semibold text-white">What you get next</div>
            <div className="mt-4 grid gap-2 text-sm text-white/70">
              {[
                "Terminal page (chart + ticket + positions)",
                "Admin session generator (24h + timed trades)",
                "Bonus unlock engine (time/trades/hybrid)",
                "Logs + exports (CSV now, PDF later)",
              ].map((x) => (
                <div key={x} className="rounded-xl border border-white/10 bg-white/5 px-4 py-3">
                  {x}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </Section>
  );
}
