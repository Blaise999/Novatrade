"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Section from "@/components/ui/Section";
import { ChevronDown } from "lucide-react";

const faqs = [
  {
    q: "Is NovaTrade a real broker?",
    a: "This build is an educational simulator. If you later add live trading, you must handle regulation, KYC/AML, disclosures, and jurisdiction requirements properly.",
  },
  {
    q: "How do controlled sessions work?",
    a: "An instructor creates a session and streams a controlled market feed (e.g., EUR/USD) for a set timeframe. Students trade inside that session so outcomes align with the lesson.",
  },
  {
    q: "Is the bonus rule a withdrawal restriction?",
    a: "No. The clean approach is a locked bonus wallet. Bonus credit remains promotional until it unlocks by time or closed trades. Your main balance stays separate.",
  },
  {
    q: "How do you prevent trade-spam to unlock bonuses?",
    a: "Count only closed trades, enforce a minimum hold time (e.g., 60 seconds), and optionally ignore micro-moves. For classrooms, closed-only + hold time is usually enough.",
  },
];

export default function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <Section id="faq">
      <h2 className="text-2xl font-semibold text-white">FAQ</h2>
      <p className="mt-2 max-w-2xl text-white/65">
        This section answers objections before they become doubts.
      </p>

      <div className="mt-8 grid gap-3">
        {faqs.map((f, idx) => {
          const isOpen = open === idx;
          return (
            <div key={f.q} className="rounded-2xl border border-white/10 bg-white/5">
              <button
                onClick={() => setOpen(isOpen ? null : idx)}
                className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left"
              >
                <div className="text-sm font-semibold text-white">{f.q}</div>
                <ChevronDown
                  className={[
                    "shrink-0 text-white/70 transition",
                    isOpen ? "rotate-180" : "rotate-0",
                  ].join(" ")}
                  size={18}
                />
              </button>

              <AnimatePresence initial={false}>
                {isOpen && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.25 }}
                    className="overflow-hidden"
                  >
                    <div className="px-5 pb-5 text-sm text-white/65">{f.a}</div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </div>
    </Section>
  );
}
