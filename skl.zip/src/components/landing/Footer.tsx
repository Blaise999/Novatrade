import Container from "@/components/ui/Container";

export default function Footer() {
  return (
    <footer className="border-t border-white/10 bg-[#070A10]/60">
      <Container className="py-10">
        <div className="flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between">
          <div className="text-sm text-white/70">
            <span className="text-white font-semibold">NovaTrade</span> — classroom trading simulator.
          </div>

          <div className="flex flex-wrap gap-4 text-sm text-white/70">
            <a href="#platform" className="hover:text-white">Platform</a>
            <a href="#pricing" className="hover:text-white">Pricing</a>
            <a href="#faq" className="hover:text-white">FAQ</a>
            <a href="#cta" className="hover:text-white">Start</a>
          </div>
        </div>

        <div className="mt-6 text-xs text-white/45">
          Risk note: If you later support live trading, trading involves risk and you must comply with applicable laws.
        </div>
      </Container>
    </footer>
  );
}
