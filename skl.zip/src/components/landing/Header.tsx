"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Menu, X } from "lucide-react";
import Container from "@/components/ui/Container";
import { ButtonLink } from "@/components/ui/Button";

const links = [
  { href: "#platform", label: "Platform" },
  { href: "#markets", label: "Markets" },
  { href: "#tools", label: "Tools" },
  { href: "#security", label: "Security" },
  { href: "#bonus", label: "Bonus rules" },
  { href: "#pricing", label: "Pricing" },
  { href: "#faq", label: "FAQ" },
];

export default function Header() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  return (
    <header
      className={[
        "sticky top-0 z-50 border-b backdrop-blur",
        scrolled ? "border-white/10 bg-[#070A10]/75" : "border-transparent bg-[#070A10]/40",
      ].join(" ")}
    >
      <Container className="flex h-16 items-center justify-between">
        <Link href="/" className="flex items-center gap-2 text-white">
          <span className="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-white/10 ring-1 ring-white/15">
            <span className="text-sm font-semibold">N</span>
          </span>
          <span className="font-semibold tracking-tight">NovaTrade</span>
        </Link>

        <nav className="hidden items-center gap-6 text-sm text-white/70 md:flex">
          {links.map((l) => (
            <a key={l.href} href={l.href} className="hover:text-white">
              {l.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <ButtonLink href="#pricing" variant="ghost" size="sm" className="hidden sm:inline-flex">
            See pricing
          </ButtonLink>
          <ButtonLink href="#cta" variant="secondary" size="sm">
            Start demo
          </ButtonLink>

          <button
            className="ml-1 inline-flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 text-white ring-1 ring-white/15 md:hidden"
            onClick={() => setOpen(true)}
            aria-label="Open menu"
          >
            <Menu size={18} />
          </button>
        </div>
      </Container>

      <AnimatePresence>
        {open && (
          <>
            <motion.div
              className="fixed inset-0 z-50 bg-black/60"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setOpen(false)}
            />
            <motion.div
              className="fixed right-0 top-0 z-50 h-full w-[86%] max-w-sm border-l border-white/10 bg-[#070A10] p-5"
              initial={{ x: 40, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: 40, opacity: 0 }}
              transition={{ type: "spring", stiffness: 280, damping: 30 }}
            >
              <div className="flex items-center justify-between">
                <div className="text-sm font-semibold text-white">NovaTrade</div>
                <button
                  className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-white/10 ring-1 ring-white/15"
                  onClick={() => setOpen(false)}
                  aria-label="Close menu"
                >
                  <X size={18} />
                </button>
              </div>

              <div className="mt-6 grid gap-2">
                {links.map((l) => (
                  <a
                    key={l.href}
                    href={l.href}
                    className="rounded-xl bg-white/5 px-4 py-3 text-sm text-white/80 ring-1 ring-white/10 hover:bg-white/10"
                    onClick={() => setOpen(false)}
                  >
                    {l.label}
                  </a>
                ))}
              </div>

              <div className="mt-6 grid gap-2">
                <ButtonLink href="#cta" variant="primary" size="lg" className="w-full">
                  Start demo
                </ButtonLink>
                <ButtonLink href="#pricing" variant="secondary" size="lg" className="w-full">
                  Instructor plan
                </ButtonLink>
              </div>

              <div className="mt-6 text-xs text-white/45">
                Educational simulator landing. Not a live brokerage.
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </header>
  );
}
