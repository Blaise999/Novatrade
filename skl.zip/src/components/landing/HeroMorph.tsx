"use client";

import { useLayoutEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { ArrowRight, ShieldCheck, Sparkles, Zap, Apple, Smartphone } from "lucide-react";
import Container from "@/components/ui/Container";
import { ButtonLink } from "@/components/ui/Button";

export default function HeroMorph() {
  const wrapRef = useRef<HTMLDivElement>(null);
  const pinRef = useRef<HTMLDivElement>(null);
  const cardRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const wrap = wrapRef.current;
    const pin = pinRef.current;
    const card = cardRef.current;
    if (!wrap || !pin || !card) return;

    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) return;

    gsap.registerPlugin(ScrollTrigger);

    const ctx = gsap.context(() => {
      const headerOffset = 64;

      gsap.set(card, { transformOrigin: "50% 50%" });

      gsap.timeline({
        scrollTrigger: {
          trigger: wrap,
          start: `top top+=${headerOffset}`,
          end: "+=950",
          scrub: true,
          pin,
          pinReparent: true,
          invalidateOnRefresh: true,
        },
      })
      .to(card, { y: -22, scale: 0.95, rotateX: 7, rotateY: -7, ease: "none" }, 0)
      .to(card, { y: -42, scale: 0.90, rotateX: 10, rotateY: -10, ease: "none" }, 0.55);
    }, wrap);

    const t = setTimeout(() => ScrollTrigger.refresh(), 120);
    return () => {
      clearTimeout(t);
      ctx.revert();
    };
  }, []);

  return (
    <div ref={wrapRef} className="relative overflow-hidden pt-10 sm:pt-16">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -top-44 left-1/2 h-[720px] w-[720px] -translate-x-1/2 rounded-full bg-[rgba(0,212,255,.14)] blur-3xl" />
        <div className="absolute -bottom-64 right-[-180px] h-[700px] w-[700px] rounded-full bg-[rgba(124,58,237,.12)] blur-3xl" />
      </div>

      <Container>
        <div ref={pinRef} className="relative">
          <div className="grid gap-10 md:grid-cols-2 md:items-center">
            <div>
              <div className="inline-flex items-center gap-2 rounded-full bg-white/8 px-3 py-1 text-xs text-white/80 ring-1 ring-white/12">
                <Sparkles size={14} />
                Tight spreads • Fast execution • Pro-grade platform
              </div>

              <h1 className="mt-5 text-balance text-4xl font-semibold tracking-tight text-white sm:text-5xl">
                Trade FX, indices, commodities & crypto with a modern broker experience.
              </h1>

              <p className="mt-4 max-w-xl text-pretty text-base leading-relaxed text-white/70">
                NovaTrade brings institutional-grade UX to retail trading: advanced charts, smart order tickets,
                real-time risk tools, and a platform designed for speed.
              </p>

              <div className="mt-7 flex flex-wrap items-center gap-3">
                <ButtonLink href="#cta" variant="primary" size="lg">
                  Create account <ArrowRight size={18} />
                </ButtonLink>
                <ButtonLink href="#platform" variant="secondary" size="lg">
                  View platform
                </ButtonLink>
              </div>

              <div className="mt-7 grid gap-3 sm:grid-cols-3">
                <Mini icon={<Zap size={16} />} title="Fast execution" desc="Optimized order flow" />
                <Mini icon={<ShieldCheck size={16} />} title="Risk controls" desc="SL/TP, limits, alerts" />
                <Mini icon={<Smartphone size={16} />} title="Multi-device" desc="Web + mobile ready" />
              </div>

              <div className="mt-6 flex flex-wrap items-center gap-3 text-xs text-white/55">
                <span className="inline-flex items-center gap-2 rounded-full bg-white/6 px-3 py-1 ring-1 ring-white/10">
                  <Apple size={14} /> iOS (placeholder)
                </span>
                <span className="inline-flex items-center gap-2 rounded-full bg-white/6 px-3 py-1 ring-1 ring-white/10">
                  <Smartphone size={14} /> Android (placeholder)
                </span>
                <span className="inline-flex items-center gap-2 rounded-full bg-white/6 px-3 py-1 ring-1 ring-white/10">
                  Web Terminal
                </span>
              </div>

              <div className="mt-4 text-xs text-white/45">
                Risk warning: Trading involves risk and may not be suitable for all investors.
              </div>
            </div>

            <div className="relative">
              <div
                ref={cardRef}
                className="rounded-3xl border border-white/12 bg-white/6 p-4 shadow-[0_50px_140px_rgba(0,0,0,.65)]"
              >
                <div className="flex items-center justify-between">
                  <div className="text-xs text-white/70">NovaTrade Web Terminal</div>
                  <div className="rounded-full bg-white/8 px-2 py-1 text-[11px] text-white/70 ring-1 ring-white/10">
                    EUR/USD • Live (placeholder)
                  </div>
                </div>

                <div className="mt-3 grid gap-3 md:grid-cols-[1fr_190px]">
                  <ChartMock />
                  <OrderTicketMock />
                </div>

                <div className="mt-3 grid gap-3 sm:grid-cols-3">
                  <KPI label="Spread from" value="0.0 pips" />
                  <KPI label="Commission" value="$0 / $3.5" />
                  <KPI label="Leverage" value="Up to X" />
                </div>

                <div className="mt-3 grid gap-3 sm:grid-cols-2">
                  <Panel title="Open positions" />
                  <Panel title="Orders & history" />
                </div>
              </div>

              <div className="mt-3 text-xs text-white/45">
                UI preview. Replace placeholders with your real specs and regulatory details.
              </div>
            </div>
          </div>
        </div>
      </Container>
    </div>
  );
}

function Mini({ icon, title, desc }: { icon: React.ReactNode; title: string; desc: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-3">
      <div className="flex items-center gap-2 text-sm text-white">
        <span className="text-white/80">{icon}</span>
        <span className="font-medium">{title}</span>
      </div>
      <div className="mt-1 text-xs text-white/60">{desc}</div>
    </div>
  );
}

function KPI({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-3">
      <div className="text-[11px] text-white/60">{label}</div>
      <div className="mt-1 text-sm font-semibold text-white">{value}</div>
    </div>
  );
}

function Panel({ title }: { title: string }) {
  return (
    <div className="h-28 rounded-2xl border border-white/10 bg-white/5 p-3">
      <div className="text-[11px] text-white/60">{title}</div>
      <div className="mt-3 h-14 rounded-xl bg-white/5 ring-1 ring-white/10" />
    </div>
  );
}

function ChartMock() {
  return (
    <div className="relative h-64 rounded-2xl bg-gradient-to-br from-white/10 to-white/5 ring-1 ring-white/10 overflow-hidden">
      <div className="absolute inset-0 opacity-[0.08] [background:radial-gradient(circle_at_30%_20%,white,transparent_55%)]" />
      <svg viewBox="0 0 600 260" className="absolute inset-0 h-full w-full">
        <path
          d="M0,190 C60,170 100,210 150,170 C200,130 240,160 290,120 C340,80 380,110 430,70 C480,30 520,60 600,40"
          fill="none"
          stroke="rgba(0,212,255,.85)"
          strokeWidth="3"
        />
        <path
          d="M0,190 C60,170 100,210 150,170 C200,130 240,160 290,120 C340,80 380,110 430,70 C480,30 520,60 600,40 L600,260 L0,260 Z"
          fill="rgba(0,212,255,.10)"
        />
      </svg>

      <div className="absolute left-4 top-4 rounded-full bg-white/8 px-2 py-1 text-[11px] text-white/70 ring-1 ring-white/10">
        Indicators • Alerts • Drawing tools
      </div>
    </div>
  );
}

function OrderTicketMock() {
  return (
    <div className="h-64 rounded-2xl bg-white/5 ring-1 ring-white/10 p-3">
      <div className="text-[11px] text-white/60">Order ticket</div>
      <div className="mt-3 grid gap-2">
        {["Market / Limit / Stop", "Size", "Stop Loss", "Take Profit"].map((x) => (
          <div key={x} className="h-10 rounded-xl bg-white/5 ring-1 ring-white/10 px-3 flex items-center text-xs text-white/65">
            {x}
          </div>
        ))}
      </div>
      <div className="mt-3 grid grid-cols-2 gap-2">
        <div className="h-10 rounded-xl bg-emerald-500/15 ring-1 ring-emerald-400/20 text-emerald-200 flex items-center justify-center text-sm">
          Buy
        </div>
        <div className="h-10 rounded-xl bg-rose-500/15 ring-1 ring-rose-400/20 text-rose-200 flex items-center justify-center text-sm">
          Sell
        </div>
      </div>
    </div>
  );
}
