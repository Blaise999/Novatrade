import Section from "@/components/ui/Section";

const markets = [
  { title: "FX (Classroom feed)", desc: "Run controlled EUR/USD sessions with clear outcomes for lessons." },
  { title: "Indices (Optional)", desc: "Add synthetic indices for pattern + risk training." },
  { title: "Commodities (Optional)", desc: "Gold & oil for macro lessons and volatility examples." },
  { title: "Crypto (Optional)", desc: "Use demo-only crypto markets for advanced sessions." },
];

export default function Markets() {
  return (
    <Section id="markets">
      <div className="grid gap-10 md:grid-cols-[1.15fr_.85fr] md:items-start">
        <div>
          <h2 className="text-2xl font-semibold text-white">Markets that match how you teach</h2>
          <p className="mt-2 max-w-2xl text-white/65">
            Your core instrument can be fully controlled (perfect for proving strategy logic),
            while other instruments can be disabled, live, or synthetic depending on the class.
          </p>

          <div className="mt-7 grid gap-4 sm:grid-cols-2">
            {markets.map((m) => (
              <div key={m.title} className="rounded-2xl border border-white/10 bg-white/5 p-5">
                <div className="text-sm font-semibold text-white">{m.title}</div>
                <div className="mt-2 text-sm text-white/65">{m.desc}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
          <div className="text-sm font-semibold text-white">Classroom default</div>
          <div className="mt-2 text-sm text-white/65">
            Only EUR/USD enabled → controlled feed → session timelines → proof logs → review panel.
          </div>
          <div className="mt-5 grid gap-2 text-sm text-white/70">
            {["Session templates", "Timed outcomes", "Student progress", "Anti-spam rules"].map((x) => (
              <div key={x} className="rounded-xl border border-white/10 bg-white/5 px-4 py-3">
                {x}
              </div>
            ))}
          </div>
        </div>
      </div>
    </Section>
  );
}
