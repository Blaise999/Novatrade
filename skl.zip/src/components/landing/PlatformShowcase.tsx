"use client";

import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import Section from "@/components/ui/Section";
import { cn } from "@/lib/cn";

const tabs = [
  {
    key: "terminal",
    title: "Trading terminal",
    blurb:
      "The same workflow students will see on real platforms: charts, order tickets, positions, and history.",
    bullets: ["Chart + indicators", "Market/limit/stop orders", "SL/TP + risk tools", "Watchlists + alerts"],
  },
  {
    key: "classroom",
    title: "Classroom mode",
    blurb:
      "You control the lesson. Create a session, pick a scenario, and stream a controlled market feed.",
    bullets: ["Timed sessions (5m, 15m, 1h)", "Scenario templates", "Lock markets per class", "Replay + review"],
  },
  {
    key: "proof",
    title: "Proof & audits",
    blurb:
      "Stop arguments. Every signal can be logged, verified, and reviewed — with timestamps and rule hits.",
    bullets: ["Rule checklist per trade", "Signal timestamps", "Export class results (later)", "Anti-cheat options"],
  },
];

export default function PlatformShowcase() {
  const [active, setActive] = useState(tabs[0]!.key);
  const current = useMemo(() => tabs.find((t) => t.key === active)!, [active]);

  return (
    <Section id="platform">
      <div className="grid gap-10 md:grid-cols-[360px_1fr] md:items-start">
        <div>
          <h2 className="text-2xl font-semibold text-white">Platform built for proof</h2>
          <p className="mt-2 text-white/65">
            NovaTrade is designed for the exact problem you described: real chart UI, but controlled outcomes
            during teaching sessions.
          </p>

          <div className="mt-7 rounded-2xl border border-white/10 bg-white/5 p-2">
            {tabs.map((t) => (
              <button
                key={t.key}
                onClick={() => setActive(t.key)}
                className={cn(
                  "relative w-full rounded-xl px-4 py-3 text-left text-sm transition",
                  active === t.key ? "text-white" : "text-white/70 hover:text-white hover:bg-white/10"
                )}
              >
                {active === t.key && (
                  <motion.span
                    layoutId="tab"
                    className="absolute inset-0 rounded-xl bg-white/10 ring-1 ring-white/15"
                    transition={{ type: "spring", stiffness: 350, damping: 35 }}
                  />
                )}
                <span className="relative">{t.title}</span>
              </button>
            ))}
          </div>
        </div>

        <motion.div
          key={current.key}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.35 }}
          className="rounded-2xl border border-white/10 bg-white/5 p-6"
        >
          <div className="text-lg font-semibold text-white">{current.title}</div>
          <div className="mt-2 text-sm text-white/65">{current.blurb}</div>

          <div className="mt-6 grid gap-3 sm:grid-cols-2">
            {current.bullets.map((b) => (
              <div key={b} className="rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white/70">
                {b}
              </div>
            ))}
          </div>

          <div className="mt-6 h-44 rounded-xl bg-gradient-to-br from-white/10 to-white/5 ring-1 ring-white/10" />
        </motion.div>
      </div>
    </Section>
  );
}
