import Section from "@/components/ui/Section";
import { ButtonLink } from "@/components/ui/Button";

const plans = [
  {
    name: "Student",
    price: "Free",
    desc: "Demo terminal + session participation.",
    feats: ["Join sessions", "Trade log view", "Rule checklist view", "Progress tracking"],
    cta: { label: "Start demo", href: "#cta", variant: "secondary" as const },
  },
  {
    name: "Instructor",
    price: "$19/mo",
    desc: "Session creation + scenarios + unlock rules.",
    feats: ["Create sessions", "Scenario templates", "Bonus unlock policies", "Class review panel"],
    highlight: true,
    cta: { label: "Get Instructor", href: "#cta", variant: "primary" as const },
  },
  {
    name: "School",
    price: "Custom",
    desc: "Multi-class + roles + audit trails.",
    feats: ["Multi-instructor", "Roles & permissions", "Audit logs", "Support + onboarding"],
    cta: { label: "Contact", href: "#cta", variant: "ghost" as const },
  },
];

export default function Pricing() {
  return (
    <Section id="pricing">
      <h2 className="text-2xl font-semibold text-white">Pricing that matches education</h2>
      <p className="mt-2 max-w-2xl text-white/65">
        Get students in free. Charge for control: session tools, admin policies, and reporting.
      </p>

      <div className="mt-8 grid gap-4 lg:grid-cols-3">
        {plans.map((p) => (
          <div
            key={p.name}
            className={[
              "rounded-2xl border bg-white/5 p-6",
              p.highlight ? "border-white/20 ring-1 ring-white/15" : "border-white/10",
            ].join(" ")}
          >
            <div className="flex items-baseline justify-between">
              <div className="text-sm font-semibold text-white">{p.name}</div>
              <div className="text-sm text-white/80">{p.price}</div>
            </div>
            <div className="mt-2 text-sm text-white/65">{p.desc}</div>

            <div className="mt-5 grid gap-2 text-sm text-white/70">
              {p.feats.map((f) => (
                <div key={f} className="rounded-xl border border-white/10 bg-white/5 px-4 py-2">
                  {f}
                </div>
              ))}
            </div>

            <div className="mt-6">
              <ButtonLink href={p.cta.href} variant={p.cta.variant} size="lg" className="w-full">
                {p.cta.label}
              </ButtonLink>
            </div>
          </div>
        ))}
      </div>
    </Section>
  );
}
