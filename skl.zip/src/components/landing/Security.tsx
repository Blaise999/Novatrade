import Section from "@/components/ui/Section";

const items = [
  { t: "Secure sessions", d: "Students join with session codes, optional expiry and capacity limits." },
  { t: "Role-based access", d: "Instructor vs student permissions, admin audit logs (later)." },
  { t: "Data integrity", d: "Trade logs are append-only during sessions to prevent manipulation." },
  { t: "Reduced-motion support", d: "Respects OS settings for accessibility." },
];

export default function Security() {
  return (
    <Section id="security">
      <div className="grid gap-10 md:grid-cols-2 md:items-start">
        <div>
          <h2 className="text-2xl font-semibold text-white">Security & trust (even for demo)</h2>
          <p className="mt-2 text-white/65">
            If you’re teaching, students still need confidence that results are consistent and logs are real.
            This section makes the platform feel “serious”.
          </p>
          <div className="mt-6 rounded-2xl border border-white/10 bg-white/5 p-5 text-sm text-white/70">
            Note: NovaTrade in this build is an <span className="text-white">educational simulator</span>.
            No real funds processed. If you later add live trading, you’ll need proper compliance and disclosures.
          </div>
        </div>

        <div className="grid gap-4">
          {items.map((x) => (
            <div key={x.t} className="rounded-2xl border border-white/10 bg-white/5 p-5">
              <div className="text-sm font-semibold text-white">{x.t}</div>
              <div className="mt-2 text-sm text-white/65">{x.d}</div>
            </div>
          ))}
        </div>
      </div>
    </Section>
  );
}
