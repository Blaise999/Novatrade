"use client";

import { useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Section from "@/components/ui/Section";

const data = [
  {
    name: "FX Instructor",
    role: "Private mentorship",
    quote:
      "The “proof mode” changes everything. No more arguments about whether the rule triggered — we can review it after.",
  },
  {
    name: "Student",
    role: "Beginner",
    quote:
      "It feels like a real broker platform, but the lessons are controlled so I actually understand what’s happening.",
  },
  {
    name: "School Admin",
    role: "Training program",
    quote:
      "We need logs and structure. NovaTrade’s session model is exactly how professional training should run.",
  },
];

export default function Testimonials() {
  const [i, setI] = useState(0);
  const current = useMemo(() => data[i]!, [i]);

  useEffect(() => {
    const t = setInterval(() => setI((x) => (x + 1) % data.length), 5500);
    return () => clearInterval(t);
  }, []);

  return (
    <Section>
      <div className="grid gap-10 md:grid-cols-[1fr_420px] md:items-center">
        <div>
          <h2 className="text-2xl font-semibold text-white">Social proof that fits your niche</h2>
          <p className="mt-2 text-white/65">
            Even if you’re early, this section sets expectations: NovaTrade is built for teaching clarity,
            not random “demo trading”.
          </p>
          <div className="mt-6 grid gap-3 sm:grid-cols-2">
            {["Cleaner lessons", "Fewer disputes", "Better retention", "Real workflow"].map((x) => (
              <div key={x} className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-white/70">
                {x}
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-2xl border border-white/10 bg-white/5 p-6">
          <div className="text-sm font-semibold text-white">What users say</div>

          <div className="mt-4 min-h-[130px]">
            <AnimatePresence mode="wait">
              <motion.div
                key={current.quote}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.35 }}
                className="text-sm text-white/70"
              >
                “{current.quote}”
              </motion.div>
            </AnimatePresence>
          </div>

          <div className="mt-5 flex items-center justify-between">
            <div>
              <div className="text-sm font-semibold text-white">{current.name}</div>
              <div className="text-xs text-white/55">{current.role}</div>
            </div>

            <div className="flex gap-2">
              {data.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => setI(idx)}
                  className={[
                    "h-2.5 w-2.5 rounded-full ring-1 ring-white/15 transition",
                    idx === i ? "bg-white" : "bg-white/20 hover:bg-white/35",
                  ].join(" ")}
                  aria-label={`Go to testimonial ${idx + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </Section>
  );
}
