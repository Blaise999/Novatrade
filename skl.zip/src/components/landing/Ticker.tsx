"use client";

const items = [
  { s: "EUR/USD", p: "1.0842", c: "+0.12%" },
  { s: "GBP/USD", p: "1.2711", c: "-0.05%" },
  { s: "USD/JPY", p: "146.32", c: "+0.08%" },
  { s: "XAU/USD", p: "2034.8", c: "+0.21%" },
  { s: "BTC/USD", p: "43,210", c: "+0.44%" },
];

export default function Ticker() {
  return (
    <div className="border-y border-white/10 bg-white/5">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <div className="relative overflow-hidden py-3">
          <div className="pointer-events-none absolute inset-y-0 left-0 w-16 bg-gradient-to-r from-[#070a10] to-transparent" />
          <div className="pointer-events-none absolute inset-y-0 right-0 w-16 bg-gradient-to-l from-[#070a10] to-transparent" />

          <div className="flex gap-8 whitespace-nowrap [animation:marquee_18s_linear_infinite]">
            {[...items, ...items].map((x, idx) => (
              <div key={idx} className="flex items-center gap-2 text-sm text-white/75">
                <span className="text-white/85">{x.s}</span>
                <span className="rounded-full bg-white/8 px-2 py-0.5 text-xs ring-1 ring-white/12">
                  {x.p}
                </span>
                <span className={x.c.startsWith("+") ? "text-emerald-300" : "text-rose-300"}>
                  {x.c}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes marquee {
          from { transform: translateX(0); }
          to { transform: translateX(-50%); }
        }
      `}</style>
    </div>
  );
}
