import Section from "@/components/ui/Section";

const tools = [
  { t: "Economic calendar", d: "Plan sessions around news events (even in a controlled feed)." },
  { t: "Alerts & watchlists", d: "Students learn real workflow: alerts → plan → execute." },
  { t: "Risk calculators", d: "Position size, risk %, R:R, and margin-style simulations." },
  { t: "Trade journal", d: "Auto-log entries, rules hit, and session notes." },
  { t: "Replay & review", d: "Replay a session and break down decision points." },
  { t: "Exports", d: "CSV now; PDF reports later (per session / per student)." },
];

export default function Tools() {
  return (
    <Section id="tools">
      <h2 className="text-2xl font-semibold text-white">Tools students actually use</h2>
      <p className="mt-2 max-w-2xl text-white/65">
        The landing page sells a full ecosystem: not just “a chart”, but a structured learning loop.
      </p>

      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {tools.map((x) => (
          <div key={x.t} className="rounded-2xl border border-white/10 bg-white/5 p-5">
            <div className="text-sm font-semibold text-white">{x.t}</div>
            <div className="mt-2 text-sm text-white/65">{x.d}</div>
          </div>
        ))}
      </div>
    </Section>
  );
}
