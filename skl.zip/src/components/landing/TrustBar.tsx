import Section from "@/components/ui/Section";

const stats = [
  { k: "Proof-first", v: "Signals logged + reviewed", d: "Rule checklist, timestamps, outcomes." },
  { k: "Controlled sessions", v: "Teach with certainty", d: "Run 5-min or 60-min sessions on demand." },
  { k: "Broker-real UI", v: "Charts, tickets, positions", d: "Students learn the real workflow." },
  { k: "Bonus unlocks", v: "By time or closed trades", d: "Promo credit stays locked until earned." },
];

export default function TrustBar() {
  return (
    <Section className="py-10 sm:py-12">
      <div className="grid gap-4 rounded-2xl border border-white/10 bg-white/5 p-5 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((s) => (
          <div key={s.k} className="rounded-2xl border border-white/10 bg-white/5 p-4">
            <div className="text-[11px] uppercase tracking-wide text-white/55">{s.k}</div>
            <div className="mt-2 text-sm font-semibold text-white">{s.v}</div>
            <div className="mt-1 text-sm text-white/65">{s.d}</div>
          </div>
        ))}
      </div>
    </Section>
  );
}
