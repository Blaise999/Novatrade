"use client";

import Link from "next/link";
import { cn } from "@/lib/cn";

type Variant = "primary" | "secondary" | "ghost";
type Size = "sm" | "md" | "lg";

const base =
  "inline-flex items-center justify-center gap-2 rounded-xl font-medium transition active:scale-[0.99] focus:outline-none focus:ring-2 focus:ring-white/15 disabled:opacity-50 disabled:pointer-events-none";

const sizes: Record<Size, string> = {
  sm: "h-9 px-3 text-sm",
  md: "h-11 px-4 text-sm",
  lg: "h-12 px-5 text-base",
};

const variants: Record<Variant, string> = {
  primary:
    "text-zinc-950 bg-gradient-to-r from-[rgba(0,212,255,1)] via-white to-[rgba(124,58,237,1)] " +
    "hover:brightness-110 shadow-[0_18px_55px_rgba(0,212,255,.18)]",
  secondary:
    "bg-white/8 text-white hover:bg-white/12 ring-1 ring-white/14 " +
    "shadow-[0_20px_60px_rgba(0,0,0,.45)]",
  ghost: "text-white/75 hover:text-white hover:bg-white/8",
};

export function Button({
  variant = "primary",
  size = "md",
  className,
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: Variant;
  size?: Size;
}) {
  return (
    <button className={cn(base, variants[variant], sizes[size], className)} {...props} />
  );
}

export function ButtonLink({
  href,
  variant = "primary",
  size = "md",
  className,
  children,
}: {
  href: string;
  variant?: Variant;
  size?: Size;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <Link href={href} className={cn(base, variants[variant], sizes[size], className)}>
      {children}
    </Link>
  );
}
